"""Claude API interface — Bob's cognitive substrate."""
from bob.api.claude import CognitiveEngine

__all__ = ["CognitiveEngine"]
